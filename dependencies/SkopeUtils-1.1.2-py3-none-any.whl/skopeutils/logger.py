"""Mixin class for better logging"""
from typing import Optional
import logging


class SkopeLogger:  # pylint: disable=too-few-public-methods
    """Mixin class for logging"""

    def __init__(self, logstr: Optional = None):
        if not logstr:
            cl = self.__class__
            module_name = cl.__module__
            classname = cl.__name__
            logstr = f"{classname}" if module_name == "builtins" else f"{module_name}.{classname}"

        self.logger = logging.getLogger(logstr)
