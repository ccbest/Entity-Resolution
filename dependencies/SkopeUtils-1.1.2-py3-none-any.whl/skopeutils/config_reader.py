"""Configuration reader object
Supports:
    - yaml/yml
    - env
"""
from __future__ import annotations
import os
from pathlib import Path
from typing import Any

import yaml

from skopeutils.deep_nesting_helpers import create_deeply_nested_dict, merge_strict
from skopeutils.logger import SkopeLogger


class ConfigReader(SkopeLogger):
    """
    Configuration reader object intended to be declared as a global in a project. Able to read
    configuration from .yaml/.yml and .env files.

    Use cases:
        - If you're switching development between local and Docker (which reads config variables
          from .env files), this will provide a consistent source of feeding config variables to
          your code instead of having to read everything from os.environ
        - If you store a bunch of secrets in a folder and don't want to refer to the files directly
        - If you have multiple configuration files

    Typically, this object will be instantiated in your project's root dir (definitions.py,
    depending on what best practices you follow) and pointed at whatever location(s) you've stored
    your configuration in.

    The reader can either load configuration from a specific file, or will walk from a directory
    searching for any compatible file extensions.

    """

    def __init__(self):
        super().__init__()
        self.settings = {}

    def __getitem__(self, key: str) -> Any:
        """
        Permits dot-delimited key retrieval from loaded config values.

        Example:
            If the config were equal to:
            {
                "key1": {
                    "key2": "retrieved_value"
                }
            }

            ...You could retrieve "retrieved_value" by passing key "key1.key2"

        Args:
            key (str): The key to look for in dot form, eg. "key1.key2"

        Returns:
            (Any) The configuration value
        """

        def get_recursive(settings, key_parts):
            # Found the desired setting
            if len(key_parts) == 0:
                return settings

            # Look for the next part of the path
            front, remaining = key_parts[0], key_parts[1:]
            if front not in settings:
                raise KeyError(f"Setting not found: {key}")

            return get_recursive(settings[front], remaining)

        parts = key.split('.')
        if not parts[0]:
            raise ValueError("No key provided.")

        if parts[0] not in self.settings:
            raise KeyError(f"Setting not found: {key}")

        return get_recursive(self.settings, parts)

    def __contains__(self, item):
        """
        Return true if a key is set in the config, and false if not
        """
        try:
            _ = self[item]
            return True
        except KeyError:
            return False

    def reset(self) -> ConfigReader:
        """
        Deletes all configuration settings and reset config object to an empty unloaded state.
        Mostly useful for unit testing.

        """
        self.settings = {}
        return self

    def load_config(self, location: Path) -> ConfigReader:
        """
        Loads configuration files from a given location. You can pass either a specific file name,
        or a directory. If you pass a directory, will execute a depth-first search for compatible
        files and load them in the order found.

        Args:
            location (Path): the location to load config files from

        Returns:
            self
        """
        if not location.exists():
            raise FileNotFoundError(f"Unable to locate config file {location}")

        if location.is_dir():
            self._walk_from_dir(location)
            return self

        if location.suffix in ('.yaml', '.yml'):
            self._load_yml_file(Path(location))

        elif location.suffix == '.env':
            self._load_env_file(Path(location))

        return self

    def _walk_from_dir(self, location: Path) -> ConfigReader:
        """
        Walks through project looking for files suffixed by ".yaml", ".yml", or ".env". All such
        files will be parsed accordingly and their variables will be added to the .settings
        property (accessible through the __getitem__ method).

        Args:
            location (Path): the location to load config files from

        Returns:
            self
        """

        for dir_name, _, file_list in os.walk(str(location)):
            for filename in file_list:
                if filename.endswith('.yaml') or filename.endswith('.yml'):
                    self._load_yml_file(Path(dir_name, filename))

                elif filename.endswith('.env'):
                    self._load_env_file(Path(dir_name, filename))

        return self

    def _load_env_file(self, path: Path) -> None:
        """
        Loads a specified .env file into the .settings property.

        Args:
            path (Path): the path of the .env file

        Returns:
            (dict) the loaded configuration variables
        """

        loaded_config = {}
        with open(str(path), 'r') as file:
            for line in file:
                if (not line) or line.strip().startswith("#") or "=" not in line:
                    continue

                # Strip out any same-line comments
                line = line.split('#')[0].strip()

                key, val = line.split('=')
                loaded_config[key] = val

        self.settings = merge_strict(self.settings, loaded_config)

    def _load_yml_file(self, path: Path) -> None:
        """
        Loads a specified YAML file

        Args:
            path (Path): the path of the .yml file
        """

        loaded = yaml.load(open(str(path), 'r'), Loader=yaml.SafeLoader)

        config = {}
        for key, value in loaded.items():
            config = merge_strict(
                config,
                create_deeply_nested_dict(key.split('.'), value)
            )

        self.settings = merge_strict(
            self.settings,
            config
        )
