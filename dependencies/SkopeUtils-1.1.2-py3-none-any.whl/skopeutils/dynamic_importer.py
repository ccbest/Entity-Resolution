"""Provides dynamic access to python modules and their functions"""
from importlib import machinery
import inspect
import os
from pathlib import Path

from skopeutils.deep_nesting_helpers import create_deeply_nested_dict, merge_strict
from skopeutils.logger import SkopeLogger


class DynamicImporter(SkopeLogger):

    """
    Creates a "registry" of functions scrubbed from .py files that can be referred to by their
    stringified names. Packages will be recursed through, and functions can be referred to by
    their corresponding package paths using dot notation, e.g. "package1.subpackage.target_function"

    Example:
        # "Normal" import process:
        from example.package import example_function

        function_result = example_function()


        # The corresponding code using this module
        function_registry = DynamicImporter()
        function_registry.load(Path(path/to/package))

        function_result = function_registry["example.package.example_function"]()

    Do NOT use this module to get around the "normal" import process (described above). The only use
    case for this code should be if you absolutely must refer to functions by their stringified
    names.

    Example use case (from Carl's Entity Resolution project):
      The project is intended to be configurable by a user/dev, and that configuration is stored in
      a .yaml file which gets read by your code. Values in that .yaml correspond to functions in
      your code, and therefore must be "looked up" by the code to find and apply the corresponding
      function.

    If your code doesn't fall under the above use case, you should ask yourself the following before
    using this:
      - Do all of my packages contain the prerequisite __init__.py file?
      - Are all of my package roots in my PYTHONPATH environment variable?

    """

    def __init__(self):
        super().__init__()
        # Deeply nested path to all functions
        self.registry = {}

        # Simple dict of all functions and their pointers
        self.leaf_functions = {}

        self._func_count = 0

    def __repr__(self) -> str:
        """Printed representation of this object"""
        return f"<DynamicImporter ({self._func_count} function" \
               f"{'s' if self._func_count != 1 else ''} registered)>"

    def __getitem__(self, key):
        """

        Args:
            key:

        Returns:

        """
        def get_recursive(dict_pointer, key_parts):
            # Found the desired function
            if not key_parts:
                return dict_pointer

            # Look for the next part of the path
            front = key_parts.pop(0)
            if front not in dict_pointer:
                raise KeyError()

            return get_recursive(dict_pointer[front], key_parts)

        # Try to find the key using recursive helper
        parts = key.split('.')
        if len(parts) == 1:
            return self.leaf_functions[key]

        return get_recursive(self.registry, parts)

    def __contains__(self, item):
        """

        Args:
            item:

        Returns:

        """
        try:
            _ = self[item]
            return True
        except KeyError:
            return False

    def load(self, path: Path) -> None:
        """

        Args:
            path:

        Returns:

        """
        if not path.is_absolute():
            path = path.absolute()

        if not path.exists():
            raise FileNotFoundError(f"Path {path} not found.")

        if path.is_dir():
            self._walk_package(path, _relative_path=[path.name])

        else:
            loaded_functions = self._get_functions_from_module(path, path.name.rstrip('.py'))

            self.registry = merge_strict(
                self.registry,
                loaded_functions
            )

    def _walk_package(self, path: Path, _relative_path: list = None):
        """
        Walks a python package (and sub-packages) looking for .py files

        Args:
            path (Path): The path of the python package

        Returns:

        """
        _relative_path = _relative_path or []
        path = path.absolute()

        for obj in os.listdir(str(path)):

            if Path(path, obj).is_dir():
                self._walk_package(
                    Path(path, obj),
                    _relative_path=_relative_path + [obj]
                )

            elif obj.endswith(".py"):

                module_name = obj.rstrip('.py')
                loaded_functions = self._get_functions_from_module(path / obj, module_name)
                if not loaded_functions[module_name]:
                    continue

                loaded_functions = create_deeply_nested_dict(
                    _relative_path + [module_name],
                    loaded_functions[module_name]
                )

                self.registry = merge_strict(
                    self.registry,
                    loaded_functions
                )

    def _get_functions_from_module(self, path: Path, module_name: str):
        """
        Pulls all of the functions out of a specified module (a .py file).

        Args:
            path (Path): the path of the module

        Returns:
            (Dict[ Dict[ <function> ] ]) A nested dictionary, where the top-level key is the module
            name, 2nd-level keys are the function names, and the corresponding values are pointers
            to the imported function.
        """
        module = machinery.SourceFileLoader(module_name, str(path))\
            .load_module(module_name)  # pylint: disable=deprecated-method
        functions = {
            item: getattr(module, item) for item in dir(module)
            if inspect.isfunction(getattr(module, item))
            and Path(inspect.getfile(getattr(module, item))) == path
            and not item.startswith('_')
        }

        self.leaf_functions.update(functions)
        self._func_count += len(functions)

        return {module_name: functions}
