"""Helpers for working with deeply nested/complex structures"""
from typing import Any, Dict, List

__all__ = ['merge_strict', 'merge_union', 'merge_overwrite', 'create_deeply_nested_dict']


def merge_strict(obj1: Any, obj2: Any, _key_path: List[str] = None):
    """
    Merges two complex structures without overriding values.

    Examples:
        # Basic example
        obj1: {"A": 1}
        obj2: {"B": 2}
        returns: {"A": 1, "B": 2}

        # Nested keys don't collide
        obj1: {"TopLevel": {"nested": "value"}}
        obj2: {"TopLevel": {"also_nested": "value"}}
        returns: {"TopLevel": {"nested": "value", "also_nested": "value"}}

        # Corresponding leaf values are different - will raise an exception
        obj1: {"TopLevel": {"nested": "value"}}
        obj2: {"TopLevel": {"nested": "different value"}}
        returns: ValueError

    Args:
        obj1: first complex structure
        obj2: second complex structure
        _key_path: Private. Keeps track of location in data structure for error reporting.

    Returns:
        Dictionary structure comprised of all key/values from both A and B
    """

    _path = _key_path or []
    for key in obj2:
        if key in obj1:
            if isinstance(obj1[key], dict) and isinstance(obj2[key], dict):
                merge_strict(obj1[key], obj2[key], _path + [str(key)])

            elif obj1[key] == obj2[key]:
                continue  # same leaf value

            else:
                raise ValueError(
                    f"Value conflict at {'.'.join(_path + [str(key)])}: {obj1[key]} != {obj2[key]}"
                )

        else:
            obj1[key] = obj2[key]

    return obj1


def merge_union(
        obj1: Any,
        obj2: Any,
        default_union_type: type = list,
        _key_path: List[str] = None
) -> Dict[str, Any]:
    """
    Merges two complex structures. Leaf values will be unioned instead of overwritten.
    The resulting union (as a list or set) will respect the original type of the
    leaf values, or will defer to the optional default_union_type parameter if
    neither are mutable collections.

    Does not mutate the original objects.

    Leaf values from the obj1 parameter will be given order priority (see fourth example).

    Examples:
        # Basic merge example
        obj1 = {"root_key": {"nested_key": "value1"}}
        obj2 = {"root_key": {"alternate_key": "value2"}}
        Returns: {"root_key": {"nested_key": "value1", "alternate_key": "value2":}}

        # Neither leaf value is a collection, so defers to default_union_type
        obj1 = {"root_key": {"nested_key": "value1"}}
        obj2 = {"root_key": {"nested_key": 2}}
        Returns: {"root_key": {"nested_key": ["value1", 2]}}

        # Leaf value from obj1 is a set, so a set is returned
        obj1 = {"root_key": {"nested_key": "value1"}}
        obj2 = {"root_key": {"nested_key": {"value1", "value2"}}}
        Returns: {"root_key": {"nested_key": {"value1", "value2"}}

        # Leaf value from obj2 is a list, but obj1 still maintains order priority
        obj1 = {"root_key": {"nested_key": "value1"}}
        obj2 = {"root_key": {"nested_key": ["value2", "value2"]}}
        Returns: {"root_key": {"nested_key": ["value1", "value2", "value3"]}}

        # Raises KeyError - obj1's leaf value is not a leaf in obj2
        obj1 = {"root_key": {"nested_key": "value1"}}
        obj2 = {"root_key": {"nested_key": {"deeply_nested_key": ["value2", "value3"]}}}
        Returns: KeyError

        # Raises ValueError - obj1 and obj2's leaf values (list and set, respectively) are
        # incapable of unioning
        obj1 = {"root_key": {"nested_key": {"value1"}}}
        obj2 = {"root_key": {"nested_key": ["value2", "value3"]}}
        Returns: ValueError

    Args:
        obj1 (Any): first complex structure
        obj2 (Any): second complex structure

        (Optionals)
        default_union_type (type): (Default list) Fives the option of specifying how to union two
                                   leaf values
        _key_path (Private): (Default None) Used to keep track of recursion location in the event
                             an error is raised.

    Returns:
        (Any) A complex data structure comprised of all kes from both A and B with their leaf values
        unioned.

    Raises:
        KeyError: If a leaf value is encountered in one of the complex structures, but its
                  counterpart is not a leaf.
        ValueError: If leaf values are of two different Collection types (e.g. one is a set and the
                    other is a list).
        ValueError: If default_union_type is defined as anything other than list or set
    """

    if (not obj1) or (not obj2):
        return obj1 or obj2

    _key_path = _key_path or []
    if default_union_type not in (list, set):
        raise ValueError("default_union_type must be list or set - "
                         f"you provided {default_union_type}")

    # If only one is a dict - KeyError
    if isinstance(obj1, dict) ^ isinstance(obj2, dict):
        raise KeyError(f"Key conflict at {'.'.join(_key_path) or 'root'}. Cannot merge a dict with "
                       f"a non-dict.")

    if isinstance(obj1, dict) and isinstance(obj2, dict):
        obj1, obj2 = obj1.copy(), obj2.copy()
        for key in obj2:
            if key in obj1:
                obj1.update(
                    {key: merge_union(
                        obj1[key],
                        obj2[key],
                        default_union_type=default_union_type,
                        _key_path=_key_path + [str(key)]
                    )}
                )
            else:
                obj1.update({key: obj2[key]})

        return obj1

    if isinstance(obj1, (list, set)) and isinstance(obj2, (list, set)):
        if not isinstance(obj1, type(obj2)):
            raise ValueError(f"Value conflict at {'.'.join(_key_path) or 'root'}. Cannot union"
                             f"a list and a set")

        return type(obj1)([*obj1, *obj2])

    if isinstance(obj1, (list, set)):
        return type(obj1)([*obj1, obj2])

    if isinstance(obj2, (list, set)):
        return type(obj2)([obj1, *obj2])

    return default_union_type([obj1, obj2])


def merge_overwrite(obj1: Any, obj2: Any, _key_path=None):
    """
    Merges two complex structures. Values in A will be overwritten by values in B if the same
    path exists.

    Examples:
        a: {"A": 1}
        b: {"B": 2}
        returns: {"A": 1, "B": 2}

        a: {"TopLevel": {"nested": "value"}}
        b: {"TopLevel": {"nested": "different_value"}}
        returns: {"TopLevel": {"nested": "different_value"}}

    Args:
        obj1: first complex structure
        obj2: second complex structure
        _key_path: Private. Keeps track of location in data structure for error reporting.

    Returns:
        Dictionary structure comprised of all key/values from both A and B
    """
    if not obj2 or not isinstance(obj2, type(obj1)):
        return obj2

    _key_path = _key_path or []
    for key in obj2:
        if key in obj1:
            if isinstance(obj1[key], dict) and isinstance(obj2[key], dict):
                merge_overwrite(obj1[key], obj2[key], _key_path + [str(key)])

            else:
                obj1[key] = obj2[key]

        else:
            obj1[key] = obj2[key]

    return obj1


def create_deeply_nested_dict(keys: list, value) -> dict:
    """
    Turns a list of key values (*args) into a deeply nested dictionary

    Example:
    create_deeply_nested_dict( ['key1', 'key2'] , 'end_value' ) =
    {
        'key1': {
            'key2': 'end_value'
        }
    }

    Args:
        keys (list): A list of keys to deeply nest, in order
        value (Any): The value of the most-deeply-nested key

    Returns:
        (dict)
    """
    if not keys:
        return {}

    out = {}
    ref = out
    key = None
    while keys:
        key = keys.pop(0)
        ref.update({key: {}})

        if keys:
            ref = ref[key]

    ref[key] = value

    return out
