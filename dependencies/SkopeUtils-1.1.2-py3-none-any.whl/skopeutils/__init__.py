"""Initialization of the skopeutils package"""
import sys

from skopeutils.pip_installer import ConditionalPipInstaller


ConditionalPipInstaller.permit_packages(
    {
        'openpyxl': 'openpyxl>=3.0.7,<4.0',
        'psycopg2': 'psycopg2-binary>=2.8.6,<3.0',
        'tqdm': 'tqdm>=4.61.0,<5.0',
        'yaml': 'pyyaml>=5.4.1,<6.0',
        'xlrd': 'xlrd>=2.0.1,<3.0',
    }
)

sys.meta_path.append(ConditionalPipInstaller)
