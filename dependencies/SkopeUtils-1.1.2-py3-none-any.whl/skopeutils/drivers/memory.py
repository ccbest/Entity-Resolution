"""Driver for writing output into global variables"""
from typing import Dict, List, Union

from skopeutils.logger import SkopeLogger
from . import Driver


class MemoryDriver(Driver, SkopeLogger):  # pylint: disable=too-few-public-methods

    """
    Driver for outputting data to local memory. Tables written will be stored as a local variable
    under the table name.
    """

    def __init__(self, global_variables):
        super().__init__()
        self.globals = global_variables

    def append_to_table(self, destination_table: str, data: List[Union[List, Dict]]) -> None:
        """
        Appends data to a "table" (in this case, the table is represented by a global variable

        Args:
            destination_table:
            data:

        Returns:

        """
        if destination_table in self.globals:
            if not isinstance(self.globals[destination_table], list):
                raise ValueError(f"The name {destination_table} already exists as a variable and "
                                 f"its value is of type {type(self.globals[destination_table])} "
                                 "(must be list)")

            self.globals.update({destination_table: self.globals[destination_table] + data})

        else:
            self.globals.update({destination_table: data})

        self.logger.info("Pushed %s records to global variable %s.", len(data), destination_table)
