"""High-level administrative helpers for PostgreSQL"""
from collections import defaultdict
import re
from typing import Any, Dict, List, Optional, Tuple

import psycopg2 as psql
from psycopg2 import extensions as psql_extensions

from skopeutils.logger import SkopeLogger
from . import Driver


class PostgreSQLDriver(Driver, SkopeLogger):

    """
    Provides low-level wrappers for common high-level workflows in PostgreSQL.
    Mostly intended for database setup, inserting records, and deleting tables.
    Doesn't support query building.

    Args:
        username (str): The user name you are using the log in to the database
        password (str): The corresponding password for the user name
        postgres_dbname (str): The name of the database in the postgres instance
        postgres_host (str): The IP address or hostname of the postgres instance
        postgres_port (int): (Default 5432) The port of the postgres instance
        db_schema (dict): Optional. See note below.

    Providing a db_schema:
    If you provide a db_schema, the driver will ensure that all specified tables/columns exist
    or create them if necessary. The schema should match the below format:

    {
        <table_name>: {
            "field_name": <the field name>,
            "postgresql_type": <the field type>
        }
    }

    Note: additional fields present under the table_name key will be ignored.

    For a complete list of PostgreSQL's field types, reference
    https://www.postgresql.org/docs/current/datatype.html

    """

    ADMIN_MODE = False  # will prevent loss of data unless switched to True

    MAX_INSERT_SIZE = 10000   # Max number of records that can be inserted with one statement

    _PSQL_DATATYPES = {
        r"bigint(?:\[\])*",
        r"int8(?:\[\])*",
        r"bigserial(?:\[\])*",
        r"serial8(?:\[\])*",
        r"bit(?:\(\d+\))?(?:\[\])*",
        r"bit varying(?:\(\d+\))?(?:\[\])*",
        r"varbit(?:\(\d+\))?(?:\[\])*",
        r"boolean(?:\[\])*",
        r"bool(?:\[\])*",
        r"box(?:\[\])*",
        r"bytea(?:\[\])*",
        r"character(?:\(\d+\))?(?:\[\])*",
        r"char(?:\(\d+\))?(?:\[\])*",
        r"character varying(?:\(\d+\))(?:\[\])*",
        r"varchar(?:\(\d+\))?(?:\[\])*",
        r"cidr(?:\[\])*",
        r"circle(?:\[\])*",
        r"date(?:\[\])*",
        r"double precision(?:\[\])*",
        r"float8(?:\[\])*",
        r"inet(?:\[\])*",
        r"integer(?:\[\])*",
        r"int(?:\[\])*",
        r"int4(?:\[\])*",
        r"interval\(\s,a-z0-9\)(?:\[\])*",
        r"json(?:\[\])*",
        r"jsonb(?:\[\])*",
        r"line(?:\[\])*",
        r"lseg(?:\[\])*",
        r"macaddr(?:\[\])*",
        r"money(?:\[\])*",
        r"numeric \d+(?:\[\])*",
        r"decimal \d+(?:\[\])*",
        r"path(?:\[\])*",
        r"pg_lsn(?:\[\])*",
        r"point(?:\[\])*",
        r"polygon(?:\[\])*",
        r"real(?:\[\])*",
        r"float4(?:\[\])*",
        r"smallint(?:\[\])*",
        r"int2(?:\[\])*",
        r"smallserial(?:\[\])*",
        r"serial2(?:\[\])*",
        r"serial(?:\[\])*",
        r"serial4(?:\[\])*",
        r"text(?:\[\])*",
        r"time(?:\(\d+\))?(?:\[\])*",
        r"time(?:\(\d+\))? with time zone(?:\[\])*",
        r"timetz(?:\[\])*",
        r"timestamp(?:\(\d+\))? with time zone(?:\[\])*",
        r"timestamptz(?:\[\])*",
        r"tsquery(?:\[\])*",
        r"tsvector(?:\[\])*",
        r"txid_snapshot(?:\[\])*",
        r"uuid(?:\[\])*",
        r"xml(?:\[\])*"
    }

    _PSQL_DATA_TYPE_RE = re.compile('|'.join(_PSQL_DATATYPES))

    def __init__(  # pylint: disable=too-many-arguments
            self,
            username: str,
            password: str,
            postgres_dbname: str,
            postgres_host: str,
            postgres_port: int = 5432,
            db_schema: Optional[Dict[str, List[Dict[str, str]]]] = None
    ):
        super().__init__()

        if not password:
            self.logger.warning("No PostgreSQL password entered. If this is because your database "
                                "has no password, you should stop what you're doing and think "
                                "about your actions.")

        self.connection = psql.connect(
            database=postgres_dbname,
            host=postgres_host,
            user=username,
            password=password,
            port=postgres_port,
        )
        self.cursor = self.connection.cursor()

        self.database_schema = self.get_database_schema()  # What's actually in the database

        self.provided_schema = db_schema or {}  # What *should* be in the database
        if self.provided_schema:
            self._validate_provided_schema(self.provided_schema)
            self._configure_db()
            self.database_schema = self.get_database_schema()  # Refresh

    def _validate_provided_schema(self, schema: dict) -> None:
        """
        Validates a provided schema for format and correctness

        Args:
            schema (dict): The provided schema for the database. See class docstring for additional
                           information.

        Returns:
            None
        """
        for tbl_name, fields in schema.items():
            for field in fields:
                if not (field.get("field_name") and field.get("postgresql_type")):
                    raise KeyError(f"{tbl_name} fields missing required keys")

                if not self._PSQL_DATA_TYPE_RE.match(field["postgresql_type"]):
                    raise ValueError(f"Field {field['field_name']} has unrecognized type "
                                     f"{field['postgresql_type']}")

    def _configure_db(self):
        """
        Performs initial setup for a database if it does not match the project's expected schema.

        Returns:
            None
        """
        schema_transform: Dict[str, Dict[str, str]] = {
            tbl_name: {field["field_name"]: field["postgresql_type"] for field in fields}
            for tbl_name, fields in self.provided_schema.items()
        }

        for table, columns in schema_transform.items():
            if table not in self.database_schema:
                self.create_table(table, columns)

            else:
                self.configure_columns(table, columns)

    def list_tables(self) -> List[str]:
        """
        Grabs the names of all tables present in the database
        """
        # Returns [ (table_name, ) ... ]
        self.cursor.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema='public' AND table_type='BASE TABLE'"
        )
        return [tbl[0] for tbl in self.cursor.fetchall()]

    def list_columns(self, tables: list) -> List[Tuple[str, str, str]]:
        """
        Returns a list of all columns associated with the provided tables.

        Returns:
            (list) A list of tuples, each with three elements:
                   ( <table_name> , <column_name>, <data_type> )
        """
        # Returns the associated columns
        self.cursor.execute(
            "SELECT table_name, column_name, data_type FROM information_schema.columns "
            "WHERE table_name = Any(%s)",
            (tables, )
        )

        return self.cursor.fetchall()

    def get_database_schema(self) -> dict:
        """
        Gets the table names, column names, and column data types for all tables in the database.

        Returns:
            (dict) { table_name: { column_name : column_data_type } }
        """
        tables = self.list_tables()
        columns = self.list_columns(tables)

        _ = defaultdict(dict)
        for tbl, col_name, data_type in columns:
            _[tbl][col_name] = data_type

        return dict(_)

    def create_table(self, tbl_name: str, columns: dict) -> True:
        """
        Creates a table. Requires config option "run_mode" to be "admin" to execute.

        Args:
            tbl_name (str): The name of the table to create
            columns (dict): A dictionary of the column names and corresponding data types, e.g. -
                    { "example_column": "text" }

        Returns:
            True

        Raises:
            ValueError: If the provided column type is not a recognized PostgreSQL data type
        """
        param_columns = [
            psql_extensions.AsIs(sub_field) for field in columns.items() for sub_field in field
        ]
        self.cursor.execute(
            f"CREATE TABLE  %s ( {', '.join(['%s %s']*len(columns))} )",
            tuple([psql_extensions.AsIs(tbl_name), *param_columns])
        )
        self.connection.commit()

        self.database_schema[tbl_name] = columns
        self.logger.info("Created table %s.", tbl_name)

        return True

    def configure_columns(self, tbl_name: str, columns: Dict[str, str]) -> True:
        """
        Verifies that columns provided by a db_schema (upon __init__) match what currently exists.

        Note that this method will create columns as needed to match the schema, but only throw a
        warning if the table contains a column that does not appear in the schema.

        Args:
            tbl_name (str): The name of the table
            columns (list): The names of the columns that are expected to exist in the table

        Returns:
            True

        Raises:
            TypeError: If the provided schema contains a column which already exists, but has
                       a different data type than the one provided.
        """
        undeclared_columns = set(self.database_schema[tbl_name]) - set(columns)
        if undeclared_columns:
            self.logger.warning("Columns %s exist in table %s but "
                                "are not declared in the provided schema.",
                                undeclared_columns, tbl_name)

        for column, data_type in columns.items():
            if column not in self.database_schema[tbl_name]:
                self.create_column(tbl_name, column, data_type)

            elif data_type != self.database_schema[tbl_name][column]:
                raise TypeError(f"(Table {tbl_name}) Column {column} already exists with "
                                "conflicting data type (currently "
                                f"{self.database_schema[tbl_name][column]} - you provided "
                                f"{data_type}).")

        return True

    def create_column(self, tbl_name: str, column_name: str, column_type: str) -> True:
        """
        Inserts a new column into a table. Requires admin mode to be enabled or will error.

        Args:
            tbl_name (str): the name of the table to create the column in
            column_name (str): the name of the column to create
            column_type (str): the type (PostgreSQL type, not pythonic) of data that will populate
                               the column

        Returns:
            True
        """

        self.cursor.execute(
            "ALTER TABLE %s ADD COLUMN %s %s",
            (psql_extensions.AsIs(tbl_name), column_name, column_type)
        )
        self.connection.commit()
        self.logger.debug("Inserted column '%s' with type %s into table %s",
                          column_name, column_type, tbl_name)
        return True

    def append_to_table(self, destination_table: str, data: List[Dict[str, Any]]) -> True:
        """
        Iterates through records, building them into a psql insert statement. Sends in chunks
        (default size is 10k - see class variable on this object)

        Args:
            destination_table (str): The name of the table in postgres that the records
                                     should be inserted to
            data (list[dict]): A list of records, in dictionary form

        Returns:
            True
        """

        if not data:
            self.logger.debug("No records to append to table %s", destination_table)
            return True

        table_keys = list(self.database_schema[destination_table].keys())

        insert_query = f"INSERT INTO %s ({', '.join(['%s']*len(table_keys))}) VALUES "
        query_params = [
            psql_extensions.AsIs(destination_table),
            *[psql_extensions.AsIs(key) for key in table_keys]
        ]

        i = 0
        while data:
            if i >= self.MAX_INSERT_SIZE:
                self.cursor.execute(insert_query, tuple(query_params))
                self.connection.commit()
                self.logger.info("Inserted %s rows into table %s", i, destination_table)
                insert_query = None
                query_params = None
                i = 1

            if not insert_query:
                insert_query = f"INSERT INTO %s ({', '.join(['%s']*len(table_keys))}) VALUES "
                query_params = [
                    psql_extensions.AsIs(destination_table),
                    *[psql_extensions.AsIs(key) for key in table_keys]
                ]

            record = data.pop()
            query_params += [record.get(field, None) for field in table_keys]
            insert_query += f"({', '.join(['%s']*len(table_keys))}), "
            i += 1

        if i > 0:
            self.cursor.execute(insert_query, tuple(query_params))
            self.connection.commit()
            self.logger.info("Inserted %s rows into table %s", i, destination_table)

        return True

    def execute_query(self, query, query_params) -> List[Tuple]:
        """
        Executes a query.

        Args:
            query (str): The query you want to execute, with variables replaced by "%s"
            query_params (tuple): A tuple of the parameters to be substituted into the query

        Returns:
            (list) a list of tuples representing the records returned
        """
        self.cursor.execute(query, query_params)
        return self.cursor.fetchall()

    def delete_table(self, tbl_name: str) -> True:
        """
        Deletes a table. Requires config option "run_mode" to be "admin" to execute and will ask
        for confirmation.

        Args:
            tbl_name (str): The name of the table to create

        Returns:
            True
        """

        if not self.ADMIN_MODE:
            raise PermissionError("The driver must be in admin mode to enable this method.")

        self.cursor.execute(
            "DROP TABLE %s",
            (psql_extensions.AsIs(tbl_name), )
        )
        self.connection.commit()

        self.database_schema.pop(tbl_name)
        self.logger.warning("Deleted table %s.", tbl_name)

        return True

    def reset_db(self):
        """
        Resets the database. Requires ADMIN_MODE to be enabled.
        Returns:
            None
        """

        if not self.ADMIN_MODE:
            raise PermissionError("The driver must be in admin mode to enable this method.")

        if input("You are about to erase all data in the database. Are you sure? (y/n)") != "y":
            return

        for table in self.database_schema:
            if table in self.database_schema:
                self.delete_table(table)
